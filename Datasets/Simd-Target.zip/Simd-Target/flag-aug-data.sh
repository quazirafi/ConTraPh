#!/bin/bash

# Ensure a path is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <path-to-search>"
    exit 1
fi

SEARCH_PATH="$1"
FLAGS_FILE="flags.txt"

# Verify the flags file exists
if [ ! -f "$FLAGS_FILE" ]; then
    echo "Flags file $FLAGS_FILE not found."
    exit 1
fi

# Recursively process each .ll file that begins with 'ir2_OUT_' in the given path and all subdirectories
find "$SEARCH_PATH" -type f -name "ir2_OUT_*.ll" | while read file_path; do
    while IFS= read -r line; do
        # Prepare line and filename for processing
        line=$(echo $line | xargs) # Trim whitespace
        flags_for_name="${line//--/}" # Sanitize flags for filename
        flags_for_name="${flags_for_name// /_}"
        flags_for_name="${flags_for_name//[^a-zA-Z0-9]/_}"

        # Construct the output file name
        prefix=$(basename "${file_path}" .ll | cut -c1-10)
		echo 'prefix' $prefix
        new_file_name="${prefix}_${flags_for_name}.ll"
		echo 'new_file_name' $new_file_name
        dir_name=$(dirname "$file_path")
        new_file_path="${dir_name}/${new_file_name}"

        # Apply all flags from the current line to the .ll file and output to the new file
        eval "opt $line \"$file_path\" -S -o \"$new_file_path\""
    done < "$FLAGS_FILE"
done

echo "Transformations applied to all matching .ll files within $SEARCH_PATH and its subdirectories."
