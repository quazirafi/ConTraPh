#!/bin/bash

# Directory containing the folders to process
DIRECTORY=$1

# Iterate over each folder in the directory
for folder in "$DIRECTORY"/*; do
  if [ -d "$folder" ]; then  # Check if it's a directory
    echo "Processing folder: $folder"
    
    # Change to the folder
    cd "$folder"
    
    # Perform commands on each C file
    for c_file in *.cpp; do
      echo "Processing file: $c_file"
      

      # Run clang command
      clang -emit-llvm -S -c -Iinclude "$c_file" -o "$c_file"-ir.ll
    done

    # Go back to the parent directory
    cd ..
  fi
done
