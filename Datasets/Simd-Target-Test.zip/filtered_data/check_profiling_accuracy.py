import os

def count_subdirs_with_json_files(directory):
    # Initialize counter
    count = 0

    # Traverse each subdirectory in the specified directory
    for subdir in os.listdir(directory):
        subdir_path = os.path.join(directory, subdir)

        # Check if it's a directory
        if os.path.isdir(subdir_path):
            # Define paths to the JSON files
            static_json_path = os.path.join(subdir_path, 'static_json.json')
            dynamic_json_path = os.path.join(subdir_path, 'dynamic_json.json')

            # Check if both files exist in the subdirectory
            if os.path.isfile(static_json_path) and os.path.isfile(dynamic_json_path):
                count += 1  # Increase counter if both files are present

    # Print the result
    print(f"Number of subdirectories containing both static_json.json and dynamic_json.json: {count}")

# Example usage:
# Replace '/path/to/directory' with the path to the main directory
count_subdirs_with_json_files('./GPU')

