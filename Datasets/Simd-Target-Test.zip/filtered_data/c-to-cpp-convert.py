import os

def convert_c_to_cpp_recursive(directory):
    # Walk through all subdirectories and files in the specified directory
    for root, dirs, files in os.walk(directory):
        for filename in files:
            file_path = os.path.join(root, filename)
            
            # Check if the file has a .c extension
            if filename.endswith('.c'):
                # Create a new filename with a .cpp extension
                new_filename = filename.rsplit('.', 1)[0] + '.cpp'
                new_file_path = os.path.join(root, new_filename)
                
                # Rename the file
                os.rename(file_path, new_file_path)
                print(f"Renamed {file_path} to {new_file_path}")
            elif filename.endswith('.cpp'):
                print(f"Skipping {file_path} (already .cpp)")

# Example usage:
# Replace '/path/to/directory' with the path to the directory containing the C/C++ files.
convert_c_to_cpp_recursive('./CPU')
convert_c_to_cpp_recursive('./GPU')
