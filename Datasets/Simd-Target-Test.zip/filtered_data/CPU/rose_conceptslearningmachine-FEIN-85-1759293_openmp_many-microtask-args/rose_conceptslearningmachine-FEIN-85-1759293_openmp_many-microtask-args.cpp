// RUN: %libomp-compile-and-run
#include <stdio.h>
#include <omp.h> 
int dummyMethod1();
int dummyMethod2();
int dummyMethod3();
int dummyMethod4();

int main()
{
  int i;
  int i1 = 0;
  int i2 = 1;
  int i3 = 2;
  int i4 = 3;
  int i5 = 4;
  int i6 = 6;
  int i7 = 7;
  int i8 = 8;
  int i9 = 9;
  int i10 = 10;
  int i11 = 11;
  int i12 = 12;
  int i13 = 13;
  int i14 = 14;
  int i15 = 15;
  int i16 = 16;
  int r = 0;
  dummyMethod1();
  
//#pragma omp parallel for private (i) reduction (+:r) firstprivate (i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16)
#pragma rose_outline
  for (i = 0; i <= i16 - 1; i += 1) {
    r += i + i1 + i2 + i3 + i4 + i5 + i6 + i7 + i8 + i9 + i10 + i11 + i12 + i13 + i14 + i15 + i16;
  }
  dummyMethod2();
  int rf = 2216;
  if (r != rf) {
    fprintf(stderr,"r should be %d but instead equals %d\n",rf,r);
    return 1;
  }
  return 0;
}

int dummyMethod1()
{
  return 0;
}

int dummyMethod2()
{
  return 0;
}

int dummyMethod3()
{
  return 0;
}

int dummyMethod4()
{
  return 0;
}
